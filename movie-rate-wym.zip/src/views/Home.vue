<template>
  <hello-world />
</template>

<script>
  import Home from '../components/Home'

  export default {
    path: '/',
    name: 'Home',
    components: Home,
  }
</script>
